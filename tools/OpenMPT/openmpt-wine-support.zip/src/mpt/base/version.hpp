/* SPDX-License-Identifier: BSL-1.0 OR BSD-3-Clause */

#ifndef MPT_BASE_VERSION_HPP
#define MPT_BASE_VERSION_HPP



#define MPT_VERSION_MAJOR 0
#define MPT_VERSION_MINOR 0
#define MPT_VERSION_PATCH 0
#define MPT_VERSION_BUILD 0



#endif // MPT_BASE_VERSION_HPP
